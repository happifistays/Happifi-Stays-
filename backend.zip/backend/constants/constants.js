export const PAYMENT_TYPE_CONSTANTS = {
  RAZORPAY: {
    id: 1,
    type: "razorpay",
  },
};
